#include "FirstAdventure.h"

namespace ng1
{
    FirstAdventure::FirstAdventure(nero::Scene::Context context):
        nero::Scene(context)
    {

    }
}


