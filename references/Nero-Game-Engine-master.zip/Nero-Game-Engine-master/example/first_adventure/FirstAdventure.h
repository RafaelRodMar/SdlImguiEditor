#ifndef FIRSTADVENTURE_H
#define FIRSTADVENTURE_H

#include <Nero/core/cpp/scene/Scene.h>

//nero game 1 (ng1)
namespace ng1
{
    class FirstAdventure : public nero::Scene
    {
        public:
        FirstAdventure(nero::Scene::Context context);
    };
}


#endif // FIRSTADVENTURE_H
