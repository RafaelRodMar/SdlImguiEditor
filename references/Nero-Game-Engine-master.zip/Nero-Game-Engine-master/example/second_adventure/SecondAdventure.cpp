#include "SecondAdventure.h"

namespace ng2
{
    SecondAdventure::SecondAdventure(nero::Scene::Context context):
        nero::LuaScene(context )
    {

    }
}

