#ifndef SECONDADVENTURE_H
#define SECONDADVENTURE_H

#include <Nero/core/cpp/luascene/LuaScene.h>

namespace ng2
{
    class SecondAdventure : public nero::LuaScene
    {
    public:
        SecondAdventure(nero::Scene::Context context);
    };
}


#endif // SECONDADVENTURE_H
