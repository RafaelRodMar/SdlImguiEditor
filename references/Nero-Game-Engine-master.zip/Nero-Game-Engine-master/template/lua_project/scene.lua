--::Project_Name::
--[[ List of available object
	 nero.
	 nero.scene
	 nero.util

--]]

nero.log("bonjour");
nero.log(nero.scene:getName());
nero.log_if("log if marche", 0 == 0);

nero.log("ok on est là", nero.logging.debug);

function handleEvent(event)

end

function update(delta_time)

end

function render()

end


