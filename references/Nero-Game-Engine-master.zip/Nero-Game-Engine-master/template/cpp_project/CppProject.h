////////////////////////////////////////////////////////////
// ::Project_Name::
// Copyright (c) ::Coypright_Date:: ::Project_Lead::
/////////////////////////////////////////////////////////////

/*
	Date 				: ::ProjectDate::
	Team Lead 	 		: ::ProjectLead::

	Project Name 		: ::ProjectName::
	Project Description	:

	::ProjectDescription::

	Team Members 		
		- ::ProjectLead::

	Project Tools
 		- Nero Game Engine
 		- Texture Packer

 	Delivery Date		: When it is done

*/
