////////////////////////////////////////////////////////////
// ::Project_Name::
// Copyright (c) ::Coypright_Date:: ::Project_Lead::
/////////////////////////////////////////////////////////////
#ifndef ::Header_Gard::
#define ::Header_Gard::
///////////////////////////HEADERS///////////////////////////
//Nero
//SFML
/////////////////////////////////////////////////////////////
namespace ::NameSpace::
{
	struct GeneratedConstant
	{
		//Project

		//Game Level

		//Game Screen

		//Startup Screen

		//Sound

		//Music

		//Object Category

		//Object Name

	};

	const struct ConstantPool : public GeneratedConstant
	{

	} ConstantPool;
}

#endif // ::Header_Gard::
