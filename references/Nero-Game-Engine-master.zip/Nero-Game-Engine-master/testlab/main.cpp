#include "PocoProcess.h"

int main()
{
	pocoProcess();

	return 0;
}
