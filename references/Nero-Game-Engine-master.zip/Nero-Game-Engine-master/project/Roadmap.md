## Nero Game Engine 2.0 Roadmap

---
#### Phase I : Nero Game Engine Reborn [status : ongoing]
---

This phase will consist to rebuild the Engine with a new Interface. The version 1.0 use SFGUI as GUI-Library. While beeing a great Library the features available are limited for the needs of the version 2.0. The Engine new Interface will use IMGUI as GUI-Library.


| status | task | description | 
| --- | --- | --- |
| status | task | description | 
| <ul><li>- [x] </li></ul> | Choose a new Code Editor | |
| <ul><li>- [x] </li></ul> | Upgrade the Compiler | |
| <ul><li>- [x] </li></ul> | Upgrade SFML | |
| <ul><li>- [x] </li></ul> | Remove SFGUI | |
| <ul><li>- [ ] </li></ul> | Design a New Interface | |


---
#### Phase II : Scripting Enable [status : not done]
---

Coming Soon
<<<<<<< HEAD:project/Roadmap.md


=======
>>>>>>> 18475d257d36ad467787b23e82b4c67e78d9fd5d:Roadmap.md
